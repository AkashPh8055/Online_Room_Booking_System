package com.app.service;

import com.app.dto.CreateBooking;
import com.app.dto.createRoom;
import com.app.pojos.Booking;
import com.app.pojos.Room;

public interface BookingServices {
//	Room createRoom(createRoom request);
	
	
	Booking CreateBooking(CreateBooking request);

//	Booking createBooking(com.app.dto.CreateBooking bookingDTO);
	
//	void updatebooking(int value ,Long id);
}
