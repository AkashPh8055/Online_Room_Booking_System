package com.app.pojos;

public enum Role {
	MANAGER, USER

}
