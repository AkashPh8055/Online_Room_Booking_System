package com.app.pojos;

public enum Room_Type {
	DELUX, NON_DELUX
}
