package com.app.service;

import java.util.List;

import com.app.dto.createRoom;
import com.app.pojos.Room;

public interface RoomService {
	Room createRoom(createRoom request);
//	Room addRoom(Room room);
//public	String deleteRoom(Long abc);
}
